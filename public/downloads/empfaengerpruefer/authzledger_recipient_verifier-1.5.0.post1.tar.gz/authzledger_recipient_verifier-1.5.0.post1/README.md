# AuthzLedger Empfängerprüfer

© Nasser Aldin Farag (0xFarag). All rights reserved.

Dieses eigenständige Python-Paket enthält den bytegleich übernommenen Offline-Prüfer des Releases v1.5.0. Der Paketname lautet `authzledger-recipient-verifier`. Die Paketrevision `1.5.0.post1` bezeichnet ausschliesslich diese Verpackung des Empfängerprüfers. Der Prüfer vergleicht Ed25519-Signatur, Dateiinventar, SHA-256-Werte und Berichtsanker. Die fachliche Richtigkeit eines Befunds erfordert die Prüfung der zugrunde liegenden Belege.

## Installation unter Linux

Erforderlich sind Python 3.10 oder neuer mit venv und pip sowie OpenSSL ab 3.0 aus einer vertrauenswürdigen Systeminstallation. Vom Verzeichnis mit dem Wheel aus:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --no-deps ./authzledger_recipient_verifier-1.5.0.post1-py3-none-any.whl
.venv/bin/authzledger-verify --help
.venv/bin/authzledger-verify ./proof --public-key ./vertrauen/mandat.pem
```

Die Verzeichnisse im Beispiel stehen für die tatsächlichen Pfade zur entpackten Übergabe und zum unabhängigen Vertrauensanker. Den erwarteten öffentlichen Schlüssel separat mit dem Absender bestätigen. Ein Duplikat des Schlüssels aus der ungeprüften Übergabe begründet kein Vertrauen. In einer ruhenden, nur lesbaren Kopie prüfen. Exitcode 0 bestätigt die strukturelle und kryptografische Prüfung, Exitcode 1 meldet eine zurückgewiesene Übergabe oder einen Prüfungsfehler. Für das direkte Ausführen der entpackten Quelle genügt `python3 -I ./authzledger_recipient_verifier.py --help`.

Der SHA-256-Wert der Originalquelle lautet `afe47e30606d61f09025fa8b2703d7446b08cc0a3093e4b82eace355bfba5303`. Der Paket-Download selbst ist unsigniert. Die beigefügten LICENSE und NOTICE.txt enthalten die Rechtehinweise.
